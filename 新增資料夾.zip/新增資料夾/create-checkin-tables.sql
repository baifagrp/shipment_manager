-- =============================================
-- 自助報到／叫號系統 - 資料庫結構
-- =============================================

-- 1. 報到記錄表
CREATE TABLE IF NOT EXISTS checkin_records (
  id BIGSERIAL PRIMARY KEY,
  checkin_no VARCHAR(20) NOT NULL UNIQUE,           -- 報到號碼 (例如: 001, 002)
  shipment_id BIGINT REFERENCES shipments(id),      -- 關聯貨件 ID
  tracking_no VARCHAR(100) NOT NULL,                -- 取件單號
  receiver_name VARCHAR(100),                        -- 收件人姓名
  receiver_phone VARCHAR(50),                        -- 收件人電話
  cod_amount DECIMAL(10,2) DEFAULT 0,               -- 代收金額
  status VARCHAR(50) DEFAULT '待叫號',              -- 狀態: 待叫號/已叫號/已完成
  store_code VARCHAR(50),                            -- 門市代號
  checkin_time TIMESTAMP DEFAULT NOW(),             -- 報到時間
  called_time TIMESTAMP,                             -- 叫號時間
  completed_time TIMESTAMP,                          -- 完成時間
  print_count INT DEFAULT 0,                         -- 列印次數
  last_print_time TIMESTAMP,                         -- 最後列印時間
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- 2. 報到號碼序列表（用於每日重置）
CREATE TABLE IF NOT EXISTS checkin_sequence (
  id SERIAL PRIMARY KEY,
  date DATE NOT NULL UNIQUE,                         -- 日期
  current_number INT DEFAULT 0,                      -- 當前號碼
  prefix VARCHAR(10) DEFAULT '',                     -- 前綴（例如：A、B）
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- 3. 叫號歷史表
CREATE TABLE IF NOT EXISTS call_history (
  id BIGSERIAL PRIMARY KEY,
  checkin_id BIGINT REFERENCES checkin_records(id),  -- 關聯報到記錄
  checkin_no VARCHAR(20) NOT NULL,                   -- 報到號碼
  caller_id UUID REFERENCES auth.users(id),          -- 叫號人員
  caller_name VARCHAR(100),                          -- 叫號人員姓名
  call_time TIMESTAMP DEFAULT NOW(),                 -- 叫號時間
  store_code VARCHAR(50),                            -- 門市代號
  created_at TIMESTAMP DEFAULT NOW()
);

-- 4. Kiosk 操作日誌表
CREATE TABLE IF NOT EXISTS kiosk_logs (
  id BIGSERIAL PRIMARY KEY,
  action VARCHAR(100) NOT NULL,                      -- 操作類型
  checkin_no VARCHAR(20),                            -- 報到號碼
  tracking_no VARCHAR(100),                          -- 取件單號
  phone_number VARCHAR(50),                          -- 查詢電話
  store_code VARCHAR(50),                            -- 門市代號
  device_id VARCHAR(100),                            -- 設備 ID
  details JSONB,                                     -- 詳細資訊
  created_at TIMESTAMP DEFAULT NOW()
);

-- =============================================
-- 索引
-- =============================================

CREATE INDEX idx_checkin_records_status ON checkin_records(status);
CREATE INDEX idx_checkin_records_store ON checkin_records(store_code);
CREATE INDEX idx_checkin_records_date ON checkin_records(DATE(checkin_time));
CREATE INDEX idx_checkin_records_tracking ON checkin_records(tracking_no);
CREATE INDEX idx_checkin_sequence_date ON checkin_sequence(date);
CREATE INDEX idx_call_history_date ON call_history(DATE(call_time));
CREATE INDEX idx_kiosk_logs_date ON kiosk_logs(DATE(created_at));

-- =============================================
-- RLS 政策
-- =============================================

-- 啟用 RLS
ALTER TABLE checkin_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE checkin_sequence ENABLE ROW LEVEL SECURITY;
ALTER TABLE call_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE kiosk_logs ENABLE ROW LEVEL SECURITY;

-- 報到記錄 - 所有已登入用戶可讀寫
CREATE POLICY "Allow authenticated users to read checkin_records"
  ON checkin_records FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow authenticated users to insert checkin_records"
  ON checkin_records FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to update checkin_records"
  ON checkin_records FOR UPDATE
  TO authenticated
  USING (true);

-- 序列表 - 所有已登入用戶可讀寫
CREATE POLICY "Allow authenticated users to access checkin_sequence"
  ON checkin_sequence FOR ALL
  TO authenticated
  USING (true);

-- 叫號歷史 - 所有已登入用戶可讀寫
CREATE POLICY "Allow authenticated users to access call_history"
  ON call_history FOR ALL
  TO authenticated
  USING (true);

-- Kiosk 日誌 - 所有已登入用戶可讀寫
CREATE POLICY "Allow authenticated users to access kiosk_logs"
  ON kiosk_logs FOR ALL
  TO authenticated
  USING (true);

-- =============================================
-- 函數：生成報到號碼
-- =============================================

CREATE OR REPLACE FUNCTION generate_checkin_no()
RETURNS VARCHAR AS $$
DECLARE
  today DATE := CURRENT_DATE;
  current_seq INT;
  new_no VARCHAR(20);
BEGIN
  -- 確保今天的序列存在
  INSERT INTO checkin_sequence (date, current_number, prefix)
  VALUES (today, 0, '')
  ON CONFLICT (date) DO NOTHING;
  
  -- 獲取並增加序列號
  UPDATE checkin_sequence
  SET current_number = current_number + 1,
      updated_at = NOW()
  WHERE date = today
  RETURNING current_number INTO current_seq;
  
  -- 生成報到號碼（三位數，例如：001, 002）
  new_no := LPAD(current_seq::TEXT, 3, '0');
  
  RETURN new_no;
END;
$$ LANGUAGE plpgsql;

-- =============================================
-- 函數：重置每日序列（可設定為定時任務）
-- =============================================

CREATE OR REPLACE FUNCTION reset_daily_checkin_sequence()
RETURNS VOID AS $$
BEGIN
  -- 清理 7 天前的舊記錄
  DELETE FROM checkin_sequence
  WHERE date < CURRENT_DATE - INTERVAL '7 days';
  
  -- 清理 30 天前的報到記錄
  DELETE FROM checkin_records
  WHERE checkin_time < NOW() - INTERVAL '30 days';
  
  -- 清理 30 天前的叫號歷史
  DELETE FROM call_history
  WHERE call_time < NOW() - INTERVAL '30 days';
  
  -- 清理 30 天前的 Kiosk 日誌
  DELETE FROM kiosk_logs
  WHERE created_at < NOW() - INTERVAL '30 days';
END;
$$ LANGUAGE plpgsql;

-- =============================================
-- 觸發器：自動更新 updated_at
-- =============================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_checkin_records_updated_at
  BEFORE UPDATE ON checkin_records
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_checkin_sequence_updated_at
  BEFORE UPDATE ON checkin_sequence
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- =============================================
-- 觸發器：防止重複報到
-- =============================================

CREATE OR REPLACE FUNCTION prevent_duplicate_checkin()
RETURNS TRIGGER AS $$
BEGIN
  -- 檢查今天是否已有相同單號的待處理報到
  IF EXISTS (
    SELECT 1 FROM checkin_records
    WHERE tracking_no = NEW.tracking_no
      AND DATE(checkin_time) = CURRENT_DATE
      AND status IN ('待叫號', '已叫號')
  ) THEN
    RAISE EXCEPTION '此取件單號今日已報到，請勿重複報到';
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER check_duplicate_checkin
  BEFORE INSERT ON checkin_records
  FOR EACH ROW
  EXECUTE FUNCTION prevent_duplicate_checkin();

-- =============================================
-- 視圖：今日報到統計
-- =============================================

CREATE OR REPLACE VIEW today_checkin_stats AS
SELECT
  DATE(checkin_time) as date,
  store_code,
  COUNT(*) as total_checkins,
  COUNT(*) FILTER (WHERE status = '待叫號') as waiting_count,
  COUNT(*) FILTER (WHERE status = '已叫號') as called_count,
  COUNT(*) FILTER (WHERE status = '已完成') as completed_count,
  AVG(EXTRACT(EPOCH FROM (completed_time - checkin_time))/60) 
    FILTER (WHERE completed_time IS NOT NULL) as avg_wait_minutes
FROM checkin_records
WHERE DATE(checkin_time) = CURRENT_DATE
GROUP BY DATE(checkin_time), store_code;

-- =============================================
-- 視圖：報到記錄詳情（含貨件資訊）
-- =============================================

CREATE OR REPLACE VIEW checkin_details AS
SELECT
  cr.id,
  cr.checkin_no,
  cr.tracking_no,
  cr.receiver_name,
  cr.receiver_phone,
  cr.cod_amount,
  cr.status,
  cr.store_code,
  cr.checkin_time,
  cr.called_time,
  cr.completed_time,
  s.item_name as shipment_item,
  s.quantity as shipment_quantity,
  s.weight as shipment_weight,
  s.status as shipment_status,
  EXTRACT(EPOCH FROM (NOW() - cr.checkin_time))/60 as wait_minutes
FROM checkin_records cr
LEFT JOIN shipments s ON cr.shipment_id = s.id
ORDER BY cr.checkin_time DESC;

-- =============================================
-- 初始化數據
-- =============================================

-- 插入今天的序列記錄
INSERT INTO checkin_sequence (date, current_number, prefix)
VALUES (CURRENT_DATE, 0, '')
ON CONFLICT (date) DO NOTHING;

-- =============================================
-- 完成提示
-- =============================================

DO $$
BEGIN
  RAISE NOTICE '✅ 自助報到／叫號系統資料庫結構創建完成！';
  RAISE NOTICE '';
  RAISE NOTICE '已創建的表：';
  RAISE NOTICE '  1. checkin_records - 報到記錄表';
  RAISE NOTICE '  2. checkin_sequence - 報到號碼序列表';
  RAISE NOTICE '  3. call_history - 叫號歷史表';
  RAISE NOTICE '  4. kiosk_logs - Kiosk 操作日誌表';
  RAISE NOTICE '';
  RAISE NOTICE '已創建的函數：';
  RAISE NOTICE '  1. generate_checkin_no() - 生成報到號碼';
  RAISE NOTICE '  2. reset_daily_checkin_sequence() - 重置每日序列';
  RAISE NOTICE '';
  RAISE NOTICE '已創建的視圖：';
  RAISE NOTICE '  1. today_checkin_stats - 今日報到統計';
  RAISE NOTICE '  2. checkin_details - 報到記錄詳情';
  RAISE NOTICE '';
  RAISE NOTICE '請在 Supabase Dashboard 執行此 SQL 檔案。';
END $$;

