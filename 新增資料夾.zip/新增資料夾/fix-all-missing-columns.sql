-- =============================================
-- 完整修復：添加所有缺失欄位和外鍵約束
-- =============================================

-- =============================================
-- 1. 修復 checkin_records 表
-- =============================================

DO $$
BEGIN
  -- 添加 shipment_id 欄位
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'checkin_records' 
    AND column_name = 'shipment_id'
  ) THEN
    ALTER TABLE checkin_records
    ADD COLUMN shipment_id BIGINT;
    RAISE NOTICE '✅ checkin_records: 已添加 shipment_id 欄位';
  ELSE
    RAISE NOTICE 'ℹ️  checkin_records: shipment_id 欄位已存在';
  END IF;
END $$;

-- 填充現有記錄的 shipment_id
UPDATE checkin_records cr
SET shipment_id = s.id
FROM shipments s
WHERE cr.tracking_no = s.tracking_no
  AND cr.shipment_id IS NULL;

-- 設定外鍵約束（CASCADE）
ALTER TABLE checkin_records
DROP CONSTRAINT IF EXISTS checkin_records_shipment_id_fkey;

ALTER TABLE checkin_records
ADD CONSTRAINT checkin_records_shipment_id_fkey
FOREIGN KEY (shipment_id)
REFERENCES shipments(id)
ON DELETE CASCADE;

-- 創建索引
CREATE INDEX IF NOT EXISTS idx_checkin_records_shipment_id 
ON checkin_records(shipment_id);

RAISE NOTICE '✅ checkin_records 表修復完成';

-- =============================================
-- 2. 修復 logs 表
-- =============================================

DO $$
BEGIN
  -- 添加 shipment_id 欄位
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'logs' 
    AND column_name = 'shipment_id'
  ) THEN
    ALTER TABLE logs
    ADD COLUMN shipment_id BIGINT;
    RAISE NOTICE '✅ logs: 已添加 shipment_id 欄位';
  ELSE
    RAISE NOTICE 'ℹ️  logs: shipment_id 欄位已存在';
  END IF;
END $$;

-- 設定外鍵約束（CASCADE）
ALTER TABLE logs
DROP CONSTRAINT IF EXISTS logs_shipment_id_fkey;

ALTER TABLE logs
ADD CONSTRAINT logs_shipment_id_fkey
FOREIGN KEY (shipment_id)
REFERENCES shipments(id)
ON DELETE CASCADE;

-- 創建索引
CREATE INDEX IF NOT EXISTS idx_logs_shipment_id 
ON logs(shipment_id);

RAISE NOTICE '✅ logs 表修復完成';

-- =============================================
-- 3. 修復 call_history 表的外鍵約束
-- =============================================

-- 更新 call_history 的外鍵（添加 CASCADE）
ALTER TABLE call_history
DROP CONSTRAINT IF EXISTS call_history_checkin_id_fkey;

ALTER TABLE call_history
ADD CONSTRAINT call_history_checkin_id_fkey
FOREIGN KEY (checkin_id)
REFERENCES checkin_records(id)
ON DELETE CASCADE;

RAISE NOTICE '✅ call_history 外鍵約束已更新';

-- =============================================
-- 4. 完成提示
-- =============================================

DO $$
BEGIN
  RAISE NOTICE '';
  RAISE NOTICE '═══════════════════════════════════════';
  RAISE NOTICE '✅ 所有表修復完成！';
  RAISE NOTICE '═══════════════════════════════════════';
  RAISE NOTICE '';
  RAISE NOTICE '已修復的表：';
  RAISE NOTICE '  1. ✅ checkin_records';
  RAISE NOTICE '     • 添加 shipment_id 欄位';
  RAISE NOTICE '     • 設定外鍵約束（ON DELETE CASCADE）';
  RAISE NOTICE '     • 創建索引';
  RAISE NOTICE '';
  RAISE NOTICE '  2. ✅ logs';
  RAISE NOTICE '     • 添加 shipment_id 欄位';
  RAISE NOTICE '     • 設定外鍵約束（ON DELETE CASCADE）';
  RAISE NOTICE '     • 創建索引';
  RAISE NOTICE '';
  RAISE NOTICE '  3. ✅ call_history';
  RAISE NOTICE '     • 更新外鍵約束（ON DELETE CASCADE）';
  RAISE NOTICE '';
  RAISE NOTICE '═══════════════════════════════════════';
  RAISE NOTICE '現在可以正常刪除貨件了！';
  RAISE NOTICE '═══════════════════════════════════════';
END $$;

-- =============================================
-- 5. 驗證所有修復
-- =============================================

-- 查看 checkin_records.shipment_id
SELECT 
  'checkin_records' as table_name,
  column_name,
  data_type,
  is_nullable
FROM information_schema.columns
WHERE table_name = 'checkin_records'
  AND column_name = 'shipment_id'

UNION ALL

-- 查看 logs.shipment_id
SELECT 
  'logs' as table_name,
  column_name,
  data_type,
  is_nullable
FROM information_schema.columns
WHERE table_name = 'logs'
  AND column_name = 'shipment_id';

-- 查看所有外鍵約束
SELECT
  tc.table_name,
  tc.constraint_name,
  kcu.column_name,
  ccu.table_name AS foreign_table_name,
  rc.delete_rule
FROM information_schema.table_constraints AS tc
JOIN information_schema.key_column_usage AS kcu
  ON tc.constraint_name = kcu.constraint_name
JOIN information_schema.constraint_column_usage AS ccu
  ON ccu.constraint_name = tc.constraint_name
JOIN information_schema.referential_constraints AS rc
  ON rc.constraint_name = tc.constraint_name
WHERE tc.constraint_type = 'FOREIGN KEY'
  AND tc.table_name IN ('checkin_records', 'logs', 'call_history')
  AND (
    kcu.column_name = 'shipment_id' 
    OR kcu.column_name = 'checkin_id'
  )
ORDER BY tc.table_name, kcu.column_name;

