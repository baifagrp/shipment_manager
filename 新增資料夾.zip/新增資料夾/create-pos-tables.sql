-- 取件結帳功能（POS 模組）資料表
-- 請在 Supabase SQL 編輯器中執行此腳本

-- =====================================
-- 1. 建立取件交易表 (pickup_transactions)
-- =====================================
CREATE TABLE IF NOT EXISTS pickup_transactions (
  id BIGSERIAL PRIMARY KEY,
  transaction_no TEXT UNIQUE NOT NULL,           -- 交易單號 (例如：TX202510270001)
  shipment_id BIGINT REFERENCES shipments(id) ON DELETE CASCADE,  -- 關聯的貨件 ID
  tracking_no TEXT NOT NULL,                     -- 取件單號 (例如：SHP-20251027-8893)
  
  -- 收件人資訊（冗餘儲存，便於查詢）
  receiver_name TEXT NOT NULL,
  receiver_phone TEXT,
  receiver_id_name TEXT,                         -- 取件人身分證姓名（用於驗證）
  
  -- 金額資訊
  amount DECIMAL(10,2) DEFAULT 0,                -- 交易金額
  payment_method TEXT DEFAULT 'cash',            -- 付款方式 (cash/card/free)
  is_cod BOOLEAN DEFAULT FALSE,                  -- 是否為貨到付款
  
  -- 操作人員與門市
  cashier_id UUID REFERENCES auth.users(id),    -- 結帳人員 ID
  cashier_name TEXT,                             -- 結帳人員姓名
  store_code TEXT,                               -- 所屬門市代號
  
  -- 狀態與時間
  status TEXT DEFAULT 'completed' CHECK (status IN ('completed', 'cancelled', 'refunded')),
  transaction_time TIMESTAMPTZ DEFAULT NOW(),    -- 交易時間
  print_count INTEGER DEFAULT 0,                 -- 列印次數
  last_print_time TIMESTAMPTZ,                   -- 最後列印時間
  
  -- 備註
  note TEXT,
  
  -- 系統欄位
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================
-- 2. 建立門市表 (stores)
-- =====================================
CREATE TABLE IF NOT EXISTS stores (
  id BIGSERIAL PRIMARY KEY,
  store_code TEXT UNIQUE NOT NULL,               -- 門市代號 (例如：ST001)
  store_name TEXT NOT NULL,                      -- 門市名稱
  address TEXT,                                  -- 門市地址
  phone TEXT,                                    -- 門市電話
  manager_name TEXT,                             -- 店長姓名
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================
-- 3. 建立操作日誌表 (pos_logs)
-- =====================================
CREATE TABLE IF NOT EXISTS pos_logs (
  id BIGSERIAL PRIMARY KEY,
  action TEXT NOT NULL,                          -- 操作類型 (pickup_scan/pickup_checkout/print_receipt/cancel_transaction)
  transaction_no TEXT,                           -- 交易單號
  tracking_no TEXT,                              -- 取件單號
  user_id UUID REFERENCES auth.users(id),       -- 操作人員
  store_code TEXT,                               -- 門市代號
  details JSONB,                                 -- 詳細資訊 (JSON 格式)
  ip_address TEXT,                               -- IP 位址
  user_agent TEXT,                               -- 瀏覽器資訊
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================
-- 4. 啟用 Row Level Security (RLS)
-- =====================================
ALTER TABLE pickup_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE stores ENABLE ROW LEVEL SECURITY;
ALTER TABLE pos_logs ENABLE ROW LEVEL SECURITY;

-- =====================================
-- 5. 建立 RLS 政策
-- =====================================

-- pickup_transactions 政策
DROP POLICY IF EXISTS "Authenticated users can view pickup transactions" ON pickup_transactions;
CREATE POLICY "Authenticated users can view pickup transactions"
ON pickup_transactions FOR SELECT
TO authenticated
USING (true);

DROP POLICY IF EXISTS "Authenticated users can create pickup transactions" ON pickup_transactions;
CREATE POLICY "Authenticated users can create pickup transactions"
ON pickup_transactions FOR INSERT
TO authenticated
WITH CHECK (true);

DROP POLICY IF EXISTS "Users can update their own transactions" ON pickup_transactions;
CREATE POLICY "Users can update their own transactions"
ON pickup_transactions FOR UPDATE
TO authenticated
USING (cashier_id = auth.uid());

-- stores 政策
DROP POLICY IF EXISTS "Everyone can view stores" ON stores;
CREATE POLICY "Everyone can view stores"
ON stores FOR SELECT
TO authenticated
USING (true);

-- pos_logs 政策
DROP POLICY IF EXISTS "Authenticated users can view pos logs" ON pos_logs;
CREATE POLICY "Authenticated users can view pos logs"
ON pos_logs FOR SELECT
TO authenticated
USING (true);

DROP POLICY IF EXISTS "Authenticated users can create pos logs" ON pos_logs;
CREATE POLICY "Authenticated users can create pos logs"
ON pos_logs FOR INSERT
TO authenticated
WITH CHECK (true);

-- =====================================
-- 6. 建立索引以提升效能
-- =====================================
CREATE INDEX IF NOT EXISTS idx_pickup_transactions_transaction_no ON pickup_transactions(transaction_no);
CREATE INDEX IF NOT EXISTS idx_pickup_transactions_tracking_no ON pickup_transactions(tracking_no);
CREATE INDEX IF NOT EXISTS idx_pickup_transactions_shipment_id ON pickup_transactions(shipment_id);
CREATE INDEX IF NOT EXISTS idx_pickup_transactions_cashier_id ON pickup_transactions(cashier_id);
CREATE INDEX IF NOT EXISTS idx_pickup_transactions_store_code ON pickup_transactions(store_code);
CREATE INDEX IF NOT EXISTS idx_pickup_transactions_transaction_time ON pickup_transactions(transaction_time DESC);
CREATE INDEX IF NOT EXISTS idx_pickup_transactions_status ON pickup_transactions(status);

CREATE INDEX IF NOT EXISTS idx_stores_store_code ON stores(store_code);
CREATE INDEX IF NOT EXISTS idx_stores_status ON stores(status);

CREATE INDEX IF NOT EXISTS idx_pos_logs_transaction_no ON pos_logs(transaction_no);
CREATE INDEX IF NOT EXISTS idx_pos_logs_tracking_no ON pos_logs(tracking_no);
CREATE INDEX IF NOT EXISTS idx_pos_logs_user_id ON pos_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_pos_logs_created_at ON pos_logs(created_at DESC);

-- =====================================
-- 7. 建立自動更新 updated_at 的觸發器
-- =====================================
CREATE TRIGGER update_pickup_transactions_updated_at 
  BEFORE UPDATE ON pickup_transactions 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_stores_updated_at 
  BEFORE UPDATE ON stores 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =====================================
-- 8. 建立自動生成交易單號的函數
-- =====================================
CREATE OR REPLACE FUNCTION generate_transaction_no()
RETURNS TEXT AS $$
DECLARE
  new_no TEXT;
  date_part TEXT;
  seq_part TEXT;
BEGIN
  -- 格式：TX + YYYYMMDD + 4位流水號
  date_part := TO_CHAR(NOW(), 'YYYYMMDD');
  
  -- 查詢今天最大的流水號
  SELECT COALESCE(MAX(SUBSTRING(transaction_no FROM 11)::INTEGER), 0) + 1
  INTO seq_part
  FROM pickup_transactions
  WHERE transaction_no LIKE 'TX' || date_part || '%';
  
  -- 組合成完整單號
  new_no := 'TX' || date_part || LPAD(seq_part::TEXT, 4, '0');
  
  RETURN new_no;
END;
$$ LANGUAGE plpgsql;

-- =====================================
-- 9. 建立防止重複取件的觸發器
-- =====================================
CREATE OR REPLACE FUNCTION check_duplicate_pickup()
RETURNS TRIGGER AS $$
BEGIN
  -- 檢查該 shipment_id 是否已有完成的取件記錄
  IF EXISTS (
    SELECT 1 FROM pickup_transactions 
    WHERE shipment_id = NEW.shipment_id 
    AND status = 'completed'
  ) THEN
    RAISE EXCEPTION '此貨件已完成取件，無法重複結帳！';
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS prevent_duplicate_pickup ON pickup_transactions;
CREATE TRIGGER prevent_duplicate_pickup
  BEFORE INSERT ON pickup_transactions
  FOR EACH ROW EXECUTE FUNCTION check_duplicate_pickup();

-- =====================================
-- 10. 建立自動更新貨件狀態的觸發器
-- =====================================
CREATE OR REPLACE FUNCTION update_shipment_on_pickup()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' AND NEW.status = 'completed' THEN
    -- 當新增取件記錄時，自動更新貨件狀態為「取件成功」
    UPDATE shipments 
    SET status = '取件成功', 
        updated_at = NOW()
    WHERE id = NEW.shipment_id;
    
    -- 記錄操作日誌
    INSERT INTO logs (action, target_table, target_id, details, created_by)
    VALUES (
      'pickup_completed', 
      'shipments', 
      NEW.shipment_id::TEXT,
      jsonb_build_object(
        'transaction_no', NEW.transaction_no,
        'tracking_no', NEW.tracking_no,
        'amount', NEW.amount,
        'cashier_name', NEW.cashier_name
      ),
      NEW.cashier_id
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS auto_update_shipment_on_pickup ON pickup_transactions;
CREATE TRIGGER auto_update_shipment_on_pickup
  AFTER INSERT ON pickup_transactions
  FOR EACH ROW EXECUTE FUNCTION update_shipment_on_pickup();

-- =====================================
-- 11. 插入預設門市資料（範例）
-- =====================================
INSERT INTO stores (store_code, store_name, address, phone, manager_name, status)
VALUES 
  ('ST001', 'BaiFa.GRP 高雄三民店', '高雄市三民區', '07-1234-5678', '王店長', 'active'),
  ('ST002', 'BaiFa.GRP 台北信義店', '台北市信義區', '02-8765-4321', '李店長', 'active')
ON CONFLICT (store_code) DO NOTHING;

-- =====================================
-- 12. 建立查詢視圖（便於前端使用）
-- =====================================
CREATE OR REPLACE VIEW pickup_transactions_view AS
SELECT 
  pt.id,
  pt.transaction_no,
  pt.tracking_no,
  pt.receiver_name,
  pt.receiver_phone,
  pt.receiver_id_name,
  pt.amount,
  pt.payment_method,
  pt.is_cod,
  pt.cashier_name,
  pt.store_code,
  s.store_name,
  pt.status,
  pt.transaction_time,
  pt.print_count,
  pt.note,
  sh.item_name,
  sh.sender_name,
  sh.created_at as shipment_created_at
FROM pickup_transactions pt
LEFT JOIN stores s ON pt.store_code = s.store_code
LEFT JOIN shipments sh ON pt.shipment_id = sh.id
ORDER BY pt.transaction_time DESC;

-- =====================================
-- 完成！
-- =====================================
SELECT '✅ POS 模組資料表已成功建立！' AS result;

